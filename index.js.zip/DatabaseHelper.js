/**
 * Created by dbeckerfl on 10/14/17.
 */

var aws = require("aws-sdk");

class DatabaseHelper {
    constructor(){
        this.dynamodb = new aws.DynamoDB({apiVersion: "2012–08–10"});
    }

    insert(userId, date, value, callback) {
        var params = {
            TableName : "JIRAVoice",
            Item: {
                userId: {
                    S: userId
                },
                entry: {
                    S: value
                }
            }
        };
        this.dynamodb.putItem(params, callback);

    }

    get(userId, callback) {
        var params = {
            TableName : "JIRAVoice",
            Key: {
                userId: {
                    S: userId
                },
                entry: {
                    S: value
                }
            },
            ProjectionExpression: "entry"
        };
        this.dynamodb.getItem(params, callback);

    }
}

exports.DatabaseHelper = DatabaseHelper;